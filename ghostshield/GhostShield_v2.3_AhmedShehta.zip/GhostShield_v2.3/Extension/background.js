const NATIVE_HOST = "com.privacyshield.helper";

// Supported Platforms configuration
const PLATFORM_PATTERNS = {
  whatsapp: ["web.whatsapp.com"],
  telegram: ["web.telegram.org", "webk.telegram.org", "webz.telegram.org"],
  facebook: ["facebook.com/messages", "facebook.com"],
  messenger: ["messenger.com"],
  instagram: ["instagram.com/direct", "instagram.com"],
  linkedin: ["linkedin.com/messaging"],
  x_twitter: ["x.com/messages", "twitter.com/messages", "x.com/i/direct_messages"],
  discord: ["discord.com/channels", "discord.com/app"],
  slack: ["slack.com", "app.slack.com"]
};

let companionPort = null;
let isCompanionConnected = false;
let currentShieldState = false;

// Default Settings including custom domains
const DEFAULT_SETTINGS = {
  masterEnabled: true,
  language: "ar",
  platforms: {
    whatsapp: true,
    telegram: true,
    facebook: true,
    messenger: true,
    instagram: true,
    linkedin: true,
    x_twitter: true,
    discord: true,
    slack: true
  },
  customDomains: []
};

let currentSettings = { ...DEFAULT_SETTINGS };

// Load settings from storage
chrome.storage.local.get(["ghostShieldSettings"], (result) => {
  if (result.ghostShieldSettings) {
    currentSettings = { 
      ...DEFAULT_SETTINGS, 
      ...result.ghostShieldSettings,
      platforms: { ...DEFAULT_SETTINGS.platforms, ...(result.ghostShieldSettings.platforms || {}) },
      customDomains: Array.isArray(result.ghostShieldSettings.customDomains) ? result.ghostShieldSettings.customDomains : []
    };
  } else {
    chrome.storage.local.set({ ghostShieldSettings: DEFAULT_SETTINGS });
  }
  checkActiveTabAndShield();
});

// Listen for settings changes
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.ghostShieldSettings) {
    currentSettings = { 
      ...DEFAULT_SETTINGS, 
      ...changes.ghostShieldSettings.newValue,
      platforms: { ...DEFAULT_SETTINGS.platforms, ...(changes.ghostShieldSettings.newValue.platforms || {}) },
      customDomains: Array.isArray(changes.ghostShieldSettings.newValue.customDomains) ? changes.ghostShieldSettings.newValue.customDomains : []
    };
    checkActiveTabAndShield();
  }
});

function connectCompanion() {
  try {
    companionPort = chrome.runtime.connectNative(NATIVE_HOST);
    isCompanionConnected = true;

    companionPort.onMessage.addListener((msg) => {
      console.log("[GhostShield Background] From Companion:", msg);
    });

    companionPort.onDisconnect.addListener(() => {
      console.warn("[GhostShield Background] Companion disconnected:", chrome.runtime.lastError?.message);
      isCompanionConnected = false;
      companionPort = null;
    });

    sendShieldState(false);
  } catch (err) {
    console.error("[GhostShield Background] Connect error:", err);
    isCompanionConnected = false;
  }
}

function sendShieldState(shouldShield) {
  if (currentShieldState === shouldShield) return;
  currentShieldState = shouldShield;

  console.log(`[GhostShield] Shield State -> ${shouldShield ? "🛡️ BLACKOUT ACTIVE" : "🟢 STREAM NORMAL"}`);

  chrome.runtime.sendNativeMessage(NATIVE_HOST, {
    action: "set_active_browser_shield",
    state: shouldShield
  }, (res) => {
    if (chrome.runtime.lastError) {
      connectCompanion();
    }
  });
}

function shouldShieldUrl(url) {
  if (!url) return false;
  const lowerUrl = url.toLowerCase();

  // 1. Check built-in platforms enabled in settings
  for (const [platformKey, patterns] of Object.entries(PLATFORM_PATTERNS)) {
    if (currentSettings.platforms && currentSettings.platforms[platformKey]) {
      for (const pattern of patterns) {
        if (lowerUrl.includes(pattern)) {
          return true;
        }
      }
    }
  }

  // 2. Check custom user-defined domains
  if (Array.isArray(currentSettings.customDomains)) {
    for (const custom of currentSettings.customDomains) {
      if (custom && custom.trim().length > 0) {
        const cleanCustom = custom.toLowerCase().trim();
        if (lowerUrl.includes(cleanCustom)) {
          return true;
        }
      }
    }
  }

  return false;
}

async function checkActiveTabAndShield() {
  if (!currentSettings.masterEnabled) {
    sendShieldState(false);
    return;
  }

  try {
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tabs || tabs.length === 0) return;

    const activeTab = tabs[0];
    const isShielded = shouldShieldUrl(activeTab.url);

    sendShieldState(isShielded);
  } catch (err) {
    console.error("[GhostShield] Tab query error:", err);
  }
}

// Tab switched
chrome.tabs.onActivated.addListener(() => {
  checkActiveTabAndShield();
});

// Tab URL updated
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tab.active && (changeInfo.url || changeInfo.status === "complete")) {
    checkActiveTabAndShield();
  }
});

// Window focus changed
chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    sendShieldState(false);
  } else {
    checkActiveTabAndShield();
  }
});

// Message handler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "check_companion") {
    chrome.runtime.sendNativeMessage(NATIVE_HOST, { action: "ping" }, (response) => {
      if (chrome.runtime.lastError) {
        sendResponse({ connected: false, error: chrome.runtime.lastError.message });
      } else {
        sendResponse({ connected: true, data: response });
      }
    });
    return true;
  }

  if (request.action === "get_status") {
    chrome.runtime.sendNativeMessage(NATIVE_HOST, { action: "get_status" }, (response) => {
      if (chrome.runtime.lastError) {
        sendResponse({ status: "error", error: chrome.runtime.lastError.message });
      } else {
        sendResponse(response);
      }
    });
    return true;
  }

  if (request.action === "unprotect_browser") {
    sendShieldState(false);
    sendResponse({ status: "ok" });
    return false;
  }
});

connectCompanion();
checkActiveTabAndShield();
