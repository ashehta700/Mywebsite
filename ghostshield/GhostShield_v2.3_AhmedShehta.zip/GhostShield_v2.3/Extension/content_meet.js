// Hook getDisplayMedia in Google Meet (MAIN World)
(function() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) return;

  const originalGetDisplayMedia = navigator.mediaDevices.getDisplayMedia.bind(navigator.mediaDevices);

  navigator.mediaDevices.getDisplayMedia = async function(...args) {
    try {
      const stream = await originalGetDisplayMedia(...args);

      window.postMessage({
        source: 'PRIVACY_SHIELD',
        type: 'SCREEN_SHARE_STATUS',
        isSharing: true
      }, '*');

      const videoTracks = stream.getVideoTracks();
      if (videoTracks.length > 0) {
        videoTracks[0].addEventListener('ended', () => {
          window.postMessage({
            source: 'PRIVACY_SHIELD',
            type: 'SCREEN_SHARE_STATUS',
            isSharing: false
          }, '*');
        });
      }

      return stream;
    } catch (err) {
      throw err;
    }
  };
})();
