// In-Tab Indicator for Protected Social Pages
(function() {
  function injectBadge() {
    if (document.getElementById('ps-ghost-status-badge')) return;

    const badge = document.createElement('div');
    badge.id = 'ps-ghost-status-badge';
    badge.style.cssText = `
      position: fixed;
      bottom: 20px;
      left: 20px;
      z-index: 9999999;
      background: rgba(20, 5, 26, 0.94);
      border: 1px solid #ffc107;
      color: #ffc107;
      padding: 7px 16px;
      border-radius: 24px;
      font-family: 'Cairo', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 12px;
      font-weight: 700;
      box-shadow: 0 4px 20px rgba(0,0,0,0.5);
      display: flex;
      align-items: center;
      gap: 8px;
      pointer-events: none;
      user-select: none;
      letter-spacing: 0.2px;
    `;
    badge.innerHTML = `<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#ffc107;box-shadow:0 0 8px #ffc107;"></span> <span>وضع الخصوصية نشط: الشات ظاهر لك ومحجوب عن المشاركة</span>`;

    document.body.appendChild(badge);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectBadge);
  } else {
    injectBadge();
  }
})();
