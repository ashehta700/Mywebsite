const TRANSLATIONS = {
  ar: {
    langBtn: "EN",
    authorTag: "حماية المحادثات أثناء مشاركة الشاشة",
    masterTitleActive: "وضع الخصوصية شغال",
    masterTitleDisabled: "وضع الخصوصية متوقف",
    masterDescActive: "شاتك ظاهر لك عادي، ومحجوب بشاشة سوداء لأي حد بيشوف شاشتك.",
    masterDescDisabled: "المحادثات هتظهر عادي لأي حد في الشير.",
    tabPlatforms: "المواقع",
    tabDesktop: "الديسكتوب",
    tabAbout: "عن الأداة",
    platformsSub: "اختر المواقع اللي تحب نحميها لما تكون مشير الشاشة:",
    customDomainsSub: "إضافة مواقع مخصصة أخرى ترغب بحجبها:",
    btnAddDomain: "+ إضافة",
    customPlaceholder: "مثال: paypal.com أو mail.google.com",
    desktopDesc: "برامج الديسكتوب المحمية على الويندوز:",
    loadingApps: "جارِ فحص البرامج...",
    noDesktopApps: "مفيش برامج شات ديسكتوب (WhatsApp/Telegram) مفتوحة حالياً",
    refreshBtn: "تحديث البرامج المشغلة",
    devBy: "تم التطوير بواسطة Ahmed Shehta",
    aboutBio: "الأداة اتعملت عشان تحل موقف بنقع فيه كلنا: وأنت في اجتماع أو بتسجل شاشتك، تفتح الواتساب أو الفيسبوك بالغلط. مع GhostShield رسايلك بتفضل باينة قدامك عادي جداً، وفي نفس اللحظة الشاشة بتظهر سوداء للمشاهدين تماماً.",
    stat1Title: "حجب تلقائي",
    stat1Desc: "أول ما تفتح تاب الشات",
    stat2Title: "خصوصية حقيقية",
    stat2Desc: "مدعومة من نظام ويندوز",
    visitSiteBtn: "زيارة موقع Ahmed Shehta",
    companionOnline: "المساعد: متصل",
    companionOffline: "المساعد: غير متصل",
    companionChecking: "المساعد: جاري الفحص",
    shieldedBadge: "محمي (شاشة سوداء)"
  },
  en: {
    langBtn: "عربي",
    authorTag: "Screen Share Chat Privacy",
    masterTitleActive: "Privacy Shield is On",
    masterTitleDisabled: "Privacy Shield is Off",
    masterDescActive: "Your chats stay visible to you, completely blacked out for viewers.",
    masterDescDisabled: "Chats will be visible to everyone on screen share.",
    tabPlatforms: "Websites",
    tabDesktop: "Desktop",
    tabAbout: "About",
    platformsSub: "Choose the platforms to protect during screen share:",
    customDomainsSub: "Add other custom websites to shield:",
    btnAddDomain: "+ Add",
    customPlaceholder: "e.g. paypal.com or mail.google.com",
    desktopDesc: "Protected desktop apps on Windows:",
    loadingApps: "Scanning active apps...",
    noDesktopApps: "No desktop chat apps (WhatsApp/Telegram) active right now",
    refreshBtn: "Refresh Active Apps",
    devBy: "Developed by Ahmed Shehta",
    aboutBio: "Built to stop awkward moments during presentations and meetings. Keep reading and typing in your personal chats while the screen share only sees a black screen.",
    stat1Title: "Auto Blackout",
    stat1Desc: "Triggers on chat tab",
    stat2Title: "True Privacy",
    stat2Desc: "Windows OS level protection",
    visitSiteBtn: "Visit Ahmed Shehta's Website",
    companionOnline: "Companion: Online",
    companionOffline: "Companion: Offline",
    companionChecking: "Companion: Checking",
    shieldedBadge: "Shielded (Black Screen)"
  }
};

let currentLang = "ar";
let settings = {
  masterEnabled: true,
  language: "ar",
  platforms: {
    whatsapp: true,
    telegram: true,
    facebook: true,
    messenger: true,
    instagram: true,
    linkedin: true,
    x_twitter: true,
    discord: true,
    slack: true
  },
  customDomains: []
};

document.addEventListener('DOMContentLoaded', () => {
  const masterToggle = document.getElementById('master-toggle');
  const masterIndicator = document.getElementById('master-indicator');
  const masterTitle = document.getElementById('master-status-title');
  const masterDesc = document.getElementById('master-status-desc');
  const langBtn = document.getElementById('lang-switch-btn');
  const companionBadge = document.getElementById('companion-badge');
  const companionText = companionBadge.querySelector('.badge-text');
  const desktopAppsList = document.getElementById('desktop-apps-list');
  const btnRefreshDesktop = document.getElementById('btn-refresh-desktop');

  const customDomainInput = document.getElementById('custom-domain-input');
  const btnAddDomain = document.getElementById('btn-add-domain');
  const customDomainsList = document.getElementById('custom-domains-list');

  // Load Settings
  chrome.storage.local.get(["ghostShieldSettings"], (res) => {
    if (res.ghostShieldSettings) {
      settings = { 
        ...settings, 
        ...res.ghostShieldSettings,
        platforms: { ...settings.platforms, ...(res.ghostShieldSettings.platforms || {}) },
        customDomains: Array.isArray(res.ghostShieldSettings.customDomains) ? res.ghostShieldSettings.customDomains : []
      };
    }
    currentLang = settings.language || "ar";
    applyLanguage(currentLang);
    applySettingsToUI();
    renderCustomDomains();
    checkCompanion();
  });

  function applyLanguage(lang) {
    currentLang = lang;
    const t = TRANSLATIONS[lang];
    document.documentElement.lang = lang;
    document.documentElement.dir = (lang === "ar") ? "rtl" : "ltr";

    langBtn.querySelector('.lang-text').textContent = t.langBtn;

    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (t[key]) {
        if (key === 'devBy') {
          el.innerHTML = (lang === 'ar') 
            ? 'تم التطوير بواسطة <strong>Ahmed Shehta</strong>' 
            : 'Developed by <strong>Ahmed Shehta</strong>';
        } else {
          el.textContent = t[key];
        }
      }
    });

    if (customDomainInput) {
      customDomainInput.placeholder = t.customPlaceholder;
    }

    updateMasterUI();
  }

  function updateMasterUI() {
    const t = TRANSLATIONS[currentLang];
    if (masterToggle.checked) {
      masterIndicator.className = 'status-circle';
      masterTitle.textContent = t.masterTitleActive;
      masterDesc.textContent = t.masterDescActive;
    } else {
      masterIndicator.className = 'status-circle disabled';
      masterTitle.textContent = t.masterTitleDisabled;
      masterDesc.textContent = t.masterDescDisabled;
    }
  }

  function applySettingsToUI() {
    masterToggle.checked = settings.masterEnabled;
    updateMasterUI();

    document.querySelectorAll('.platform-toggle').forEach(input => {
      const platform = input.getAttribute('data-platform');
      if (settings.platforms && settings.platforms[platform] !== undefined) {
        input.checked = settings.platforms[platform];
      }
    });
  }

  function saveSettings() {
    settings.masterEnabled = masterToggle.checked;
    settings.language = currentLang;

    document.querySelectorAll('.platform-toggle').forEach(input => {
      const platform = input.getAttribute('data-platform');
      settings.platforms[platform] = input.checked;
    });

    chrome.storage.local.set({ ghostShieldSettings: settings });
  }

  // Render Custom Domains
  function renderCustomDomains() {
    customDomainsList.innerHTML = '';
    if (!Array.isArray(settings.customDomains)) settings.customDomains = [];

    settings.customDomains.forEach((domain, index) => {
      const chip = document.createElement('div');
      chip.className = 'domain-chip';
      chip.innerHTML = `
        <span>${escapeHtml(domain)}</span>
        <span class="chip-remove" data-index="${index}" title="حذف">&times;</span>
      `;
      customDomainsList.appendChild(chip);
    });

    // Delete chip events
    customDomainsList.querySelectorAll('.chip-remove').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(e.target.getAttribute('data-index'));
        settings.customDomains.splice(idx, 1);
        saveSettings();
        renderCustomDomains();
      });
    });
  }

  function addCustomDomain() {
    let val = customDomainInput.value.trim().toLowerCase();
    if (!val) return;

    // Clean URL
    val = val.replace(/^https?:\/\//, '').replace(/\/.*$/, '').trim();

    if (val.length > 2 && !settings.customDomains.includes(val)) {
      settings.customDomains.push(val);
      saveSettings();
      renderCustomDomains();
      customDomainInput.value = '';
    }
  }

  if (btnAddDomain) {
    btnAddDomain.addEventListener('click', addCustomDomain);
  }
  if (customDomainInput) {
    customDomainInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        addCustomDomain();
      }
    });
  }

  masterToggle.addEventListener('change', () => {
    updateMasterUI();
    saveSettings();
  });

  document.querySelectorAll('.platform-toggle').forEach(input => {
    input.addEventListener('change', () => {
      saveSettings();
    });
  });

  langBtn.addEventListener('click', () => {
    const nextLang = (currentLang === "ar") ? "en" : "ar";
    applyLanguage(nextLang);
    saveSettings();
  });

  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const targetId = btn.getAttribute('data-tab');
      document.getElementById(targetId).classList.add('active');

      if (targetId === 'tab-desktop') {
        loadDesktopApps();
      }
    });
  });

  function checkCompanion() {
    const t = TRANSLATIONS[currentLang];
    chrome.runtime.sendMessage({ action: 'check_companion' }, (res) => {
      if (res && res.connected) {
        companionBadge.className = 'companion-pill active';
        companionText.textContent = t.companionOnline;
        loadDesktopApps();
      } else {
        companionBadge.className = 'companion-pill offline';
        companionText.textContent = t.companionOffline;
      }
    });
  }

  function loadDesktopApps() {
    const t = TRANSLATIONS[currentLang];
    chrome.runtime.sendMessage({ action: 'get_status' }, (res) => {
      if (!res || res.status !== 'ok' || !res.windows || res.windows.length === 0) {
        desktopAppsList.innerHTML = `<div class="empty-state">${t.noDesktopApps}</div>`;
        return;
      }

      desktopAppsList.innerHTML = '';
      res.windows.forEach(win => {
        const item = document.createElement('div');
        item.className = 'desktop-app-item';
        item.innerHTML = `
          <div class="desktop-app-title">
            <span class="tag-badge sm">${getTagBadge(win.process)}</span>
            <span>${escapeHtml(win.process)}</span>
          </div>
          <span class="desktop-app-status">${t.shieldedBadge}</span>
        `;
        desktopAppsList.appendChild(item);
      });
    });
  }

  function getTagBadge(proc) {
    const p = proc.toLowerCase();
    if (p.includes('whatsapp')) return 'WA';
    if (p.includes('telegram')) return 'TG';
    if (p.includes('messenger') || p.includes('facebook')) return 'FB';
    if (p.includes('discord')) return 'DC';
    if (p.includes('slack')) return 'SL';
    return 'APP';
  }

  function escapeHtml(text) {
    const d = document.createElement('div');
    d.textContent = text;
    return d.innerHTML;
  }

  btnRefreshDesktop.addEventListener('click', () => {
    checkCompanion();
  });
});
