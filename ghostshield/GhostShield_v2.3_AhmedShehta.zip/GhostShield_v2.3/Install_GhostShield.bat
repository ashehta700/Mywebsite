@echo off
title GhostShield Setup - by Ahmed Shehta
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install_GhostShield.ps1"
