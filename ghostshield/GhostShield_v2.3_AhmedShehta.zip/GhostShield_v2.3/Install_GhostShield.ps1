# GhostShield Installer by Ahmed Shehta
$ErrorActionPreference = "Stop"

Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "   GhostShield by Ahmed Shehta - Setup" -ForegroundColor Cyan
Write-Host "   Privacy Screen Protector for Meetings & Recordings" -ForegroundColor Cyan
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host ""

$scriptDir = $PSScriptRoot
$companionExe = Join-Path $scriptDir "Companion\PrivacyShield.Companion.exe"
$hostJson = Join-Path $scriptDir "Companion\com.privacyshield.helper.json"
$extensionDir = Join-Path $scriptDir "Extension"

if (-not (Test-Path $companionExe)) {
    Write-Host "[ERROR] Companion executable not found at: $companionExe" -ForegroundColor Red
    pause
    exit 1
}

Write-Host "[*] Configuring Native Messaging Host for your PC..." -ForegroundColor Yellow

$escapedExe = (Resolve-Path $companionExe).Path.Replace('\', '\\')

$manifestData = @{
    name = "com.privacyshield.helper"
    description = "GhostShield Windows Companion by Ahmed Shehta"
    path = $escapedExe
    type = "stdio"
    allowed_origins = @("chrome-extension://kbjebnoiekhdhdcalbbcfjlcmfdkohkf/")
}

$jsonContent = $manifestData | ConvertTo-Json -Depth 5
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($hostJson, $jsonContent, $utf8NoBom)

Write-Host "[*] Registering with Windows Registry for Chrome and Edge..." -ForegroundColor Yellow

$chromeKey = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.privacyshield.helper"
$edgeKey = "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\com.privacyshield.helper"

if (-not (Test-Path $chromeKey)) { New-Item -Path $chromeKey -Force | Out-Null }
Set-ItemProperty -Path $chromeKey -Name "(Default)" -Value $hostJson | Out-Null

if (-not (Test-Path $edgeKey)) { New-Item -Path $edgeKey -Force | Out-Null }
Set-ItemProperty -Path $edgeKey -Name "(Default)" -Value $hostJson | Out-Null

Write-Host ""
Write-Host "=========================================================" -ForegroundColor Green
Write-Host "  [SUCCESS] GhostShield Companion Registered Successfully!" -ForegroundColor Green
Write-Host "=========================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Next simple step (takes 5 seconds):" -ForegroundColor Cyan
Write-Host "1. Chrome will open to: chrome://extensions"
Write-Host "2. Enable [Developer mode] at the top right."
Write-Host "3. Click [Load unpacked] and select this folder:"
Write-Host "   $extensionDir" -ForegroundColor Yellow
Write-Host ""
Write-Host "Press any key to open Chrome and start using GhostShield..."

$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

Start-Process "chrome.exe" "chrome://extensions"
