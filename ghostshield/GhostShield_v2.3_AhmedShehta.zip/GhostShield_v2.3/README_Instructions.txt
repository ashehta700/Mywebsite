===========================================================
  GhostShield by Ahmed Shehta (v2.2 Pro)
  Official Website: https://ahmed-shehta.netlify.app/
===========================================================

[ بالعربية - طريقة التشغيل في 10 ثوانٍ ]

1. فك ضغط الملف.
2. اضغط مرتين على ملف:
   Install_GhostShield.bat
   (سيقوم بربط المساعد بالمتصفح تلقائياً ويفتح لك صفحة الإضافات).

3. في صفحة المتصفح التي ستفتح أمامك (chrome://extensions):
   - فعّل خيار [وضع المطور - Developer mode] من أعلى اليمين.
   - اضغط على زر [تحميل إضافة غير محزومة - Load unpacked].
   - اختر مجلد (Extension) الموجود داخل هذا المجلد.

مبروك! الآن شاتك محمي تماماً أثناء أي اجتماع أو تسجيل شاشة!


===========================================================
[ ENGLISH - 10-Second Quick Start ]

1. Extract this ZIP file.
2. Double-click:
   Install_GhostShield.bat
   (Configures the Windows companion and opens chrome://extensions).

3. In the extensions page (chrome://extensions):
   - Toggle ON [Developer mode] at the top right.
   - Click [Load unpacked].
   - Select the (Extension) folder inside this directory.

Done! Your chats are now completely protected during screen shares!
===========================================================
