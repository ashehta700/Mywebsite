@echo off
title Uninstall GhostShield
color 0E

echo =========================================================
echo   GhostShield Uninstaller
echo =========================================================
echo.
echo Removing GhostShield from Windows Registry...

reg delete "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.privacyshield.helper" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.privacyshield.helper" /f >nul 2>&1

taskkill /f /im PrivacyShield.Companion.exe >nul 2>&1

color 0A
echo.
echo [DONE] GhostShield unregistered successfully.
echo You can now remove the extension from chrome://extensions.
echo.
pause
